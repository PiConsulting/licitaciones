import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { beforeEach, describe, expect, test, vi } from "vitest";

import { ChecklistCategoryCard } from "./ChecklistCategoryCard";
import type { CategoryData } from "../analysis-detail/types";
import type { TrackingCategory } from "../../types/tracking";

const listTrackingComments = vi.fn();

vi.mock("../../api/tracking", () => ({
  listTrackingComments: (...args: unknown[]) => listTrackingComments(...args),
}));

const category: CategoryData = {
  items: [],
  confidence: 0,
  source_references: [],
  extraction_status: "success",
  summary: "",
  is_reviewed: false,
  narrative: {
    blocks: [
      {
        type: "bullet_list",
        items: [
          { titulo: "Inscripción vigente", text: "Presentar constancia.", confidence_level: "high", source_ids: [0] },
          { titulo: "Garantía de oferta", text: "Acompañar la garantía.", confidence_level: "high", source_ids: [1] },
        ],
      },
    ],
    sources: [
      { id: 0, document_id: "doc-1", document_name: "Pliego", page: 3, text: "a" },
      { id: 1, document_id: "doc-1", document_name: "Pliego", page: 4, text: "b" },
    ],
  },
};

function buildTrackingCategory(status: TrackingCategory["status"] = "in_review"): TrackingCategory {
  return {
    category_key: "requisitos_admisibilidad",
    status,
    comments_count: 0,
    items: [
      {
        tracking_item_id: "item-1",
        category_key: "requisitos_admisibilidad",
        status: "not_evaluated",
        comments_count: 2,
        source_item_ref: { version_id: "v1", field_name: "a", document_id: "doc-1", page: 3 },
      },
      {
        tracking_item_id: "item-2",
        category_key: "requisitos_admisibilidad",
        status: "not_evaluated",
        comments_count: 0,
        source_item_ref: { version_id: "v1", field_name: "b", document_id: "doc-1", page: 4 },
      },
    ],
  };
}

function renderCard(overrides: Partial<Parameters<typeof ChecklistCategoryCard>[0]> = {}) {
  const props = {
    analysisId: "an-1",
    categoryId: "requisitos_admisibilidad" as const,
    category,
    trackingCategory: buildTrackingCategory(),
    isOpen: true,
    readOnly: false,
    actionLoading: false,
    onToggleOpen: vi.fn(),
    onToggleClosed: vi.fn(),
    onChangeItemStatus: vi.fn(),
    onCreateComment: vi.fn().mockResolvedValue(undefined),
    onUpdateComment: vi.fn().mockResolvedValue(undefined),
    onDeleteComment: vi.fn().mockResolvedValue(undefined),
    ...overrides,
  };
  const queryClient = new QueryClient({ defaultOptions: { queries: { retry: false } } });
  render(
    <QueryClientProvider client={queryClient}>
      <ChecklistCategoryCard {...props} />
    </QueryClientProvider>,
  );
  return props;
}

describe("ChecklistCategoryCard comentarios por ítem", () => {
  beforeEach(() => {
    listTrackingComments.mockReset();
    listTrackingComments.mockResolvedValue([]);
  });

  test("cada ítem tiene su ícono de comentarios con el contador propio y no hay panel de categoría", () => {
    renderCard();

    expect(screen.getByRole("button", { name: "Comentarios: Inscripción vigente (2)" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Comentarios: Garantía de oferta" })).toBeInTheDocument();
    expect(screen.queryByText("Agregar comentario")).not.toBeInTheDocument();
    expect(screen.queryByRole("region", { name: /Comentarios de seguimiento/ })).not.toBeInTheDocument();
  });

  test("abrir un ítem lista solo los comentarios de ese ítem", async () => {
    listTrackingComments.mockResolvedValue([
      {
        id: "c1",
        analysis_id: "an-1",
        version_id: "v1",
        category_key: "requisitos_admisibilidad",
        scope: "checklist_item",
        tracking_item_id: "item-1",
        content: "Falta la constancia",
        created_by: "u1",
        created_by_name: "Ana",
        created_at: "2026-09-29T10:00:00Z",
      },
    ]);
    renderCard();

    fireEvent.click(screen.getByRole("button", { name: "Comentarios: Inscripción vigente (2)" }));

    expect(await screen.findByText("Falta la constancia")).toBeInTheDocument();
    expect(listTrackingComments).toHaveBeenCalledWith("an-1", "requisitos_admisibilidad", {
      scope: "checklist_item",
      trackingItemId: "item-1",
    });
  });

  test("guardar un comentario lo envía con el id del ítem", async () => {
    const props = renderCard();

    fireEvent.click(screen.getByRole("button", { name: "Comentarios: Garantía de oferta" }));
    fireEvent.change(await screen.findByLabelText("Nuevo comentario: Garantía de oferta"), {
      target: { value: "Vence en octubre" },
    });
    fireEvent.click(screen.getByRole("button", { name: "Guardar comentario" }));

    await waitFor(() => expect(props.onCreateComment).toHaveBeenCalledWith("item-2", "Vence en octubre"));
  });

  test("con la categoría cerrada no se puede comentar", async () => {
    renderCard({ trackingCategory: buildTrackingCategory("closed") });

    fireEvent.click(screen.getByRole("button", { name: "Comentarios: Garantía de oferta" }));

    expect(await screen.findByText("Reabrí la categoría para comentar.")).toBeInTheDocument();
    expect(screen.queryByLabelText("Nuevo comentario: Garantía de oferta")).not.toBeInTheDocument();
  });
});
