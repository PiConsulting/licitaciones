import { useState } from "react";
import { useQuery } from "@tanstack/react-query";

import { listTrackingComments } from "../../api/tracking";
import { trackingCommentsQueryKey } from "../analysis-detail/hooks/useTrackingMutations";

interface ChecklistItemCommentsProps {
  analysisId: string;
  categoryKey: string;
  trackingItemId: string;
  itemLabel: string;
  readOnly: boolean;
  closed: boolean;
  loading: boolean;
  onCreate: (content: string) => Promise<void>;
  onUpdate: (commentId: string, content: string) => Promise<void>;
  onDelete: (commentId: string) => Promise<void>;
}

function formatDateTime(value: string): string {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return "Fecha no disponible";
  }
  return new Intl.DateTimeFormat("es-AR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(date);
}

export function ChecklistItemComments({
  analysisId,
  categoryKey,
  trackingItemId,
  itemLabel,
  readOnly,
  closed,
  loading,
  onCreate,
  onUpdate,
  onDelete,
}: ChecklistItemCommentsProps) {
  const [text, setText] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingText, setEditingText] = useState("");

  const query = useQuery({
    queryKey: trackingCommentsQueryKey(analysisId, categoryKey, trackingItemId),
    queryFn: () =>
      listTrackingComments(analysisId, categoryKey, { scope: "checklist_item", trackingItemId }),
  });
  const comments = query.data ?? [];
  const canWrite = !readOnly && !closed;

  return (
    <section
      aria-label={`Comentarios del ítem: ${itemLabel}`}
      className="flex flex-col gap-2.5 rounded-xl border border-[rgba(0,60,107,.1)] bg-[#F4F9FC] p-3"
    >
      {query.isLoading ? <p className="text-xs text-[rgba(0,60,107,.55)]">Cargando comentarios...</p> : null}
      {!query.isLoading && comments.length === 0 ? (
        <p className="text-xs text-[rgba(0,60,107,.55)]">Todavía no hay comentarios en este ítem.</p>
      ) : null}

      {comments.map((comment) => (
        <div key={comment.id} className="rounded-lg border border-[rgba(0,60,107,.1)] bg-white px-3 py-2.5">
          <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-[rgba(0,60,107,.55)]">
            <span className="font-semibold text-[#003C6B]">
              {(comment.created_by_name ?? "").trim() || comment.created_by}
            </span>
            <span>{formatDateTime(comment.created_at)}</span>
          </div>
          {editingId === comment.id ? (
            <div className="mt-2">
              <textarea
                aria-label="Editar comentario"
                value={editingText}
                onChange={(event) => setEditingText(event.target.value)}
                disabled={loading}
                className="min-h-[64px] w-full rounded-lg border border-[rgba(0,60,107,.2)] px-2.5 py-2 text-sm text-[#003C6B]"
              />
              <div className="mt-2 flex items-center gap-2">
                <button
                  type="button"
                  disabled={loading || editingText.trim().length === 0}
                  onClick={async () => {
                    await onUpdate(comment.id, editingText);
                    setEditingId(null);
                    setEditingText("");
                  }}
                  className="inline-flex h-7 items-center rounded-full bg-[#003C6B] px-3 text-xs font-semibold text-white transition-colors hover:bg-[#0099DB] disabled:opacity-50"
                >
                  Guardar edición
                </button>
                <button
                  type="button"
                  disabled={loading}
                  onClick={() => {
                    setEditingId(null);
                    setEditingText("");
                  }}
                  className="inline-flex h-7 items-center rounded-full px-3 text-xs font-semibold text-[rgba(0,60,107,.68)] hover:text-[#003C6B]"
                >
                  Cancelar
                </button>
              </div>
            </div>
          ) : (
            <p className="mt-1 whitespace-pre-wrap text-sm text-[#003C6B]">{comment.content}</p>
          )}
          {comment.edited_at ? (
            <p className="mt-1 text-[11px] text-[rgba(0,60,107,.55)]">{`Editado ${formatDateTime(comment.edited_at)}`}</p>
          ) : null}
          {canWrite && editingId !== comment.id ? (
            <div className="mt-2 flex items-center gap-3">
              <button
                type="button"
                disabled={loading}
                onClick={() => {
                  setEditingId(comment.id);
                  setEditingText(comment.content);
                }}
                className="text-xs font-semibold text-[#0099DB] hover:text-[#003C6B]"
              >
                Editar
              </button>
              <button
                type="button"
                disabled={loading}
                onClick={() => {
                  void onDelete(comment.id);
                }}
                className="text-xs font-semibold text-[#DC2626] hover:text-[#B91C1C]"
              >
                Eliminar
              </button>
            </div>
          ) : null}
        </div>
      ))}

      {canWrite ? (
        <div className="flex flex-col gap-2">
          <textarea
            aria-label={`Nuevo comentario: ${itemLabel}`}
            placeholder="Escribí un comentario sobre este ítem"
            value={text}
            onChange={(event) => setText(event.target.value)}
            disabled={loading}
            className="min-h-[64px] w-full rounded-lg border border-[rgba(0,60,107,.2)] bg-white px-2.5 py-2 text-sm text-[#003C6B]"
          />
          <div className="flex justify-end">
            <button
              type="button"
              disabled={loading || text.trim().length === 0}
              onClick={async () => {
                await onCreate(text);
                setText("");
              }}
              className="inline-flex h-8 items-center rounded-full bg-[#003C6B] px-3.5 text-xs font-semibold text-white transition-colors hover:bg-[#0099DB] disabled:opacity-50"
            >
              Guardar comentario
            </button>
          </div>
        </div>
      ) : null}

      {!readOnly && closed ? (
        <p className="text-xs text-[rgba(0,60,107,.55)]">Reabrí la categoría para comentar.</p>
      ) : null}
    </section>
  );
}
